# 🛒 WeBizzle!
**WhatsApp Price Comparison & Boda Boda Delivery — Built for Kenya**

> Compare prices from local vendors, pay via M-Pesa, and get boda boda delivery — all without leaving WhatsApp.

---

## 📐 Architecture

```
Customer / Vendor / Rider
        │  WhatsApp
        ▼
Meta Cloud API ─── POST /webhook ──► Node.js (Express)
                                           │
                  ┌────────────────────────┼─────────────────────┐
                  ▼                        ▼                     ▼
             Supabase DB            M-Pesa Daraja          Rider Dispatch
          (state + orders)         (STK Push pay)       (auto-assign boda)
```

**Free-tier stack — zero monthly cost to launch:**

| Service | Purpose | Free Tier |
|---|---|---|
| Meta Cloud API | WhatsApp messaging | 1,000 conversations/mo |
| Supabase | PostgreSQL database | 500 MB, 2 projects |
| Render.com | Node.js hosting | 750 hrs/mo |
| M-Pesa Daraja | Payments | Free (sandbox + production) |

---

## 🚀 Setup Guide (30 minutes)

### Step 1 — Supabase Database
1. Go to supabase.com → New Project
2. Open SQL Editor → New Query
3. Paste contents of `database/schema.sql` and click Run
4. Go to Settings → API and copy:
   - Project URL → SUPABASE_URL
   - service_role key → SUPABASE_SERVICE_KEY

### Step 2 — Meta WhatsApp Cloud API
1. Go to developers.facebook.com → Create App → Business
2. Add WhatsApp product
3. Under API Setup, note your Phone Number ID → WHATSAPP_PHONE_NUMBER_ID
4. Generate a Permanent Access Token (System Users → Admin → whatsapp_business_messaging)
5. Copy → WHATSAPP_ACCESS_TOKEN

### Step 3 — M-Pesa Daraja (Safaricom)
1. Go to developer.safaricom.co.ke → Sign Up
2. Create an app → add Lipa Na M-Pesa Online API
3. Copy Consumer Key and Consumer Secret
4. Sandbox: Short Code 174379, passkey from their docs

### Step 4 — Deploy to Render.com
1. Push project to GitHub
2. render.com → New Web Service → connect repo
3. Build Command: `npm install` | Start Command: `npm start`
4. Add all env vars from .env.example
5. Copy your Render URL

### Step 5 — Connect WhatsApp Webhook
1. Meta Console → WhatsApp → Configuration → Webhooks
2. Callback URL: https://your-app.onrender.com/webhook
3. Verify Token: same as WEBHOOK_VERIFY_TOKEN in .env
4. Subscribe to: messages field

### Step 6 — Update M-Pesa Callback URL
Set MPESA_CALLBACK_URL=https://your-app.onrender.com/mpesa-callback in Render env vars.

---

## 🧪 Local Testing with ngrok

```bash
npm install
cp .env.example .env
# fill in .env

npm run dev
# in second terminal:
npx ngrok http 3000
# use the ngrok HTTPS URL for webhook + mpesa callback
```

---

## 💬 How to Use

### Customer
1. Text anything → "Hi" to your WhatsApp Business number
2. Enter your name → see main menu
3. Tap Search → type "tomatoes" → see price comparison
4. Select vendor → Add to Cart → Checkout
5. Share delivery location → confirm order → pay via M-Pesa
6. Get assigned a boda boda rider → track delivery live

### Vendor
1. Text "VENDOR" → fill in business name, location, category, M-Pesa number
2. Auto-approved → tap Add Product → set name, price, unit, stock
3. Receive order notifications on WhatsApp automatically

### Rider
1. Text "RIDER" → fill in name, ID number, bike registration
2. Auto-approved → tap Go Online
3. Receive delivery job notifications → Accept → Collect → Deliver
4. Get paid daily via M-Pesa

---

## 🛠 Admin API

All endpoints require header: X-Admin-Token: YOUR_ADMIN_TOKEN

```
GET  /admin/stats                        # Dashboard stats
GET  /admin/vendors/pending              # Vendors awaiting approval
POST /admin/vendors/:id/approve          # Approve a vendor
GET  /admin/riders/pending               # Riders awaiting approval
POST /admin/riders/:id/approve           # Approve a rider
```

---

## 📁 Project Structure

```
webizzle/
├── index.js                    # Express server + admin routes
├── package.json
├── .env.example
├── src/
│   ├── handlers/
│   │   └── webhookHandler.js   # Webhook verify + message router
│   ├── flows/
│   │   ├── customerFlow.js     # Search, cart, checkout, rating
│   │   ├── vendorFlow.js       # Onboarding, products, orders
│   │   └── riderFlow.js        # Registration, delivery lifecycle
│   ├── services/
│   │   ├── whatsapp.js         # Meta Cloud API send functions
│   │   ├── mpesa.js            # Daraja STK Push + auto-assign rider
│   │   └── db.js               # Supabase CRUD operations
│   └── utils/
│       └── helpers.js          # formatPrice, truncate, sanitizePhone
└── database/
    └── schema.sql              # Tables, indexes, RLS, seed data
```

---

## 🔒 Going to Production

1. Set NODE_ENV=production in Render
2. Use real Safaricom paybill credentials (not sandbox)
3. Set is_approved: false in vendor/rider flows for manual review via admin API
4. Add Sentry or Pino for error logging
5. Upgrade Supabase if you exceed 500 MB

---

Built with love for Kenya 🇰🇪 — Powered by WeBizzle!
